/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mlyexamenex2;

/**
 *
 * @author yago.martinezloureda
 */
public class MLYExamenEX2 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
