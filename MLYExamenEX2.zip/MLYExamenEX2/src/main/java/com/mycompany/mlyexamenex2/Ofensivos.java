/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mlyexamenex2;

/**
 *
 * @author yago.martinezloureda
 */
public abstract class Ofensivos extends Jugador{

    public abstract void atacar ();
}
