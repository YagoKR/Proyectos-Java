/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.fernandowirtz.mly_tarea04;

/**
 *
 * @author yago.martinezloureda
 */
public class MLY_tarea04 {

    public static void main(String[] args) {
        Supermercado supermercado = new Supermercado(3);
        supermercado.generarClientes();
    }
}
