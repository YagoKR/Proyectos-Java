/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.time.LocalDateTime;

/**
 *
 * @author yago.martinezloureda
 */
public class Alarma {
    public LocalDateTime momento;
    public String mensaje;

    public Alarma(LocalDateTime momento, String mensaje) {
        this.momento = momento;
        this.mensaje = mensaje;
    }

    public LocalDateTime getMomento() {
        return momento;
    }

    public void setMomento(LocalDateTime momento) {
        this.momento = momento;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    @Override
    public String toString() {
        return "Momento=" + momento + ", mensaje=" + mensaje + '}';
    }
    
    
}
