/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package gal.unidad2.di_activdad2;

/**
 *
 * @author yago.martinezloureda
 */
public class DI_Activdad2 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
